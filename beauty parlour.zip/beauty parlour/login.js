


function myfunction(){
    var x =document.getElementById("password");

    if(x.type === "password"){
        x.type = "text";
    }
    else{
        x.type = "password";
    }
}


function validate(){
    var password = document.getElementById("password");
    var length = document.getElementById("length");

    if(password.value.length >= 8){
        alert("Login Succesfull");
        window.location.replace("index.html");
        return false;
    }
    else{
        alert("Login Failed");
    }
}







































